import Menu from "../Components/menu";

export default function Pagina2(){
    return(
        <main>
            <Menu/>
        </main>
    );
}